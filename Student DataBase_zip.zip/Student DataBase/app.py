from flask import Flask, request, render_template, redirect, url_for
import psycopg2

def run_query():
    conn = psycopg2.connect(
        database="UNIVERSITY",
        user="postgres",
        password=78692,  
        host="localhost",
        port=5432
    )
    cur = conn.cursor()
    cur.execute("SELECT id RollNumber, Name, dept_name as subject FROM student;")
    response = cur.fetchall()
    cur.close()
    conn.close()
    return response


database = {
    "Ariz": "123",
    "Aman": "121",
    "Rehan":"12345",
    "Emaad":"777"
}

app = Flask(__name__, template_folder="html_folder", static_folder="css_folder")

@app.route("/", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        
        if username in database and database[username] == password:
            return redirect(url_for("student"))
        else:
            return render_template("invalid.html")
    return render_template("login.html")

@app.route("/forgot", methods=["GET", "POST"])
def forgot():
    if request.method == "POST":
        username = request.form.get("username")
        if username in database:
            recovery_pass = database[username]
            return render_template("forgot_result.html", username=username, recovery_pass=recovery_pass)
        return render_template("forgot_result.html", error="Username not found.")
    return render_template("forgot_form.html")

@app.route("/student")
def student():
    return render_template("student.html", data=run_query())

if __name__ == "__main__":
    app.run(debug=False)
